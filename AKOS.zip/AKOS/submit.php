<?php
// check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // retrieve the form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // perform validation on the form data
    $errors = array();

    if (empty($name)) {
        $errors[] = "Name is required";
    }

    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    if (empty($message)) {
        $errors[] = "Message is required";
    }

    // if there are no errors, send the email and redirect to the thank you page
    if (count($errors) == 0) {
        // send the email
        $to = "youremail@example.com";
        $subject = "New Contact Form Submission";
        $message_body = "Name: $name\nEmail: $email\nMessage:\n$message";
        $headers = "From: $email\n";
        mail($to, $subject, $message_body, $headers);

        // redirect to the thank you page
        header("Location: thankyou.html");
        exit();
    }
}
?>
